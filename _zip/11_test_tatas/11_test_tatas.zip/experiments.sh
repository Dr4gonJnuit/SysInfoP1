LAUNCH_FILE=TAS
#NAME_OF_FILE=temps_prod_cons_POSIX

echo "Lancement du temps du test de TATAS :"

./performance/bash/temps_$LAUNCH_FILE.sh cat #$NAME_OF_FILE
